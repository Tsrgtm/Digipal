<img src="{{ asset('assets/images/favicon.png') }}" alt="Digipal Icon">
