<x-layouts.app.top>
    {{ $slot }}
</x-layouts.app.top>
