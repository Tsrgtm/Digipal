<img src="<?php echo e(asset('assets/images/favicon.png')); ?>" alt="Digipal Icon">
<?php /**PATH C:\Users\Acer\Downloads\DigipalReborn\resources\views/components/app-logo-icon.blade.php ENDPATH**/ ?>