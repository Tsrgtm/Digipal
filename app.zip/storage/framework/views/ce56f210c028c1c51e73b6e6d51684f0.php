<?php if (isset($component)) { $__componentOriginalaf2d1a211c584d1313db504fc8aeaa34 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaf2d1a211c584d1313db504fc8aeaa34 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app.top','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app.top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo e($slot); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaf2d1a211c584d1313db504fc8aeaa34)): ?>
<?php $attributes = $__attributesOriginalaf2d1a211c584d1313db504fc8aeaa34; ?>
<?php unset($__attributesOriginalaf2d1a211c584d1313db504fc8aeaa34); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaf2d1a211c584d1313db504fc8aeaa34)): ?>
<?php $component = $__componentOriginalaf2d1a211c584d1313db504fc8aeaa34; ?>
<?php unset($__componentOriginalaf2d1a211c584d1313db504fc8aeaa34); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Acer\Downloads\DigipalReborn\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>