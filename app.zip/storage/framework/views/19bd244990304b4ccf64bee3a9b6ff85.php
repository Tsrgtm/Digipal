<div
    class="bg-green-600 dark:bg-green-800 hidden lg:flex items-center justify-between border-b-[.5px] border-stone-100 dark:border-stone-800 text-sm">
    <div class="flex items-center justify-between gap-6 px-4 py-1 max-w-7xl mx-auto w-full">
        <div class="flex items-center gap-5">
            <a href="https://g.co/kgs/Jv43MfK" target="_blank"
                class="text-white dark:text-zinc-400 hover:text-green-100 dark:hover:text-green-400 flex gap-2 items-center hover:scale-101 transition-all duration-300 ease-in-out">
                <?php if (isset($component)) { $__componentOriginal0d48bd54d72df81b49ee07c1a3735f04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.map-pin','data' => ['class' => 'w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.map-pin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04)): ?>
<?php $attributes = $__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04; ?>
<?php unset($__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d48bd54d72df81b49ee07c1a3735f04)): ?>
<?php $component = $__componentOriginal0d48bd54d72df81b49ee07c1a3735f04; ?>
<?php unset($__componentOriginal0d48bd54d72df81b49ee07c1a3735f04); ?>
<?php endif; ?>
                <span>Dillibazar,Kathmandu</span>
            </a>

            <a href="mailto:hello@digipalsolutions.com.np"
                class="text-white dark:text-zinc-400 hover:text-green-100 dark:hover:text-green-400 flex gap-2 items-center hover:scale-101 transition-all duration-300 ease-in-out">
                <?php if (isset($component)) { $__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.envelope','data' => ['class' => 'w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.envelope'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f)): ?>
<?php $attributes = $__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f; ?>
<?php unset($__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f)): ?>
<?php $component = $__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f; ?>
<?php unset($__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f); ?>
<?php endif; ?>
                <span>hello@digipalsolutions.com.np</span>
            </a>

            <a href="tel:+977 01-5912819"
                class="text-white dark:text-zinc-400 hover:text-green-100 dark:hover:text-green-400 flex gap-2 items-center hover:scale-101 transition-all duration-300 ease-in-out">
                <?php if (isset($component)) { $__componentOriginal3b273e6b331c9518de08da49e1886441 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b273e6b331c9518de08da49e1886441 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.phone','data' => ['class' => 'w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.phone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b273e6b331c9518de08da49e1886441)): ?>
<?php $attributes = $__attributesOriginal3b273e6b331c9518de08da49e1886441; ?>
<?php unset($__attributesOriginal3b273e6b331c9518de08da49e1886441); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b273e6b331c9518de08da49e1886441)): ?>
<?php $component = $__componentOriginal3b273e6b331c9518de08da49e1886441; ?>
<?php unset($__componentOriginal3b273e6b331c9518de08da49e1886441); ?>
<?php endif; ?>
                <span>+977 01-5912819</span>
            </a>
        </div>

        <div class="flex items-center gap-5">
            <a href="https://g.co/kgs/Jv43MfK" target="_blank"
                class="text-white dark:text-zinc-400 hover:text-green-100 dark:hover:text-green-400 hover:scale-101 transition-all duration-300 ease-in-out">
                <?php if (isset($component)) { $__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.facebook','data' => ['class' => 'w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.facebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442)): ?>
<?php $attributes = $__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442; ?>
<?php unset($__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442)): ?>
<?php $component = $__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442; ?>
<?php unset($__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442); ?>
<?php endif; ?>
            </a>

            <a href="https://g.co/kgs/Jv43MfK" target="_blank"
                class="text-white dark:text-zinc-400 hover:text-green-100 dark:hover:text-green-400 hover:scale-101 transition-all duration-300 ease-in-out">
                <?php if (isset($component)) { $__componentOriginala94603789a3397061ae5e0ddf097082b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala94603789a3397061ae5e0ddf097082b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.instagram','data' => ['class' => 'w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.instagram'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala94603789a3397061ae5e0ddf097082b)): ?>
<?php $attributes = $__attributesOriginala94603789a3397061ae5e0ddf097082b; ?>
<?php unset($__attributesOriginala94603789a3397061ae5e0ddf097082b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala94603789a3397061ae5e0ddf097082b)): ?>
<?php $component = $__componentOriginala94603789a3397061ae5e0ddf097082b; ?>
<?php unset($__componentOriginala94603789a3397061ae5e0ddf097082b); ?>
<?php endif; ?>
            </a>

            <a href="https://g.co/kgs/Jv43MfK" target="_blank"
                class="text-white dark:text-zinc-400 hover:text-green-100 dark:hover:text-green-400 hover:scale-101 transition-all duration-300 ease-in-out">
                <?php if (isset($component)) { $__componentOriginal74ea8ed9b57f968e47449b6924350724 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74ea8ed9b57f968e47449b6924350724 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.linkedin','data' => ['class' => 'w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.linkedin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74ea8ed9b57f968e47449b6924350724)): ?>
<?php $attributes = $__attributesOriginal74ea8ed9b57f968e47449b6924350724; ?>
<?php unset($__attributesOriginal74ea8ed9b57f968e47449b6924350724); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74ea8ed9b57f968e47449b6924350724)): ?>
<?php $component = $__componentOriginal74ea8ed9b57f968e47449b6924350724; ?>
<?php unset($__componentOriginal74ea8ed9b57f968e47449b6924350724); ?>
<?php endif; ?>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Acer\Downloads\DigipalReborn\resources\views/components/app-top.blade.php ENDPATH**/ ?>