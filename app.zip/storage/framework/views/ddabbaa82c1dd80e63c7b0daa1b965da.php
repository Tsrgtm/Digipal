<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body
    class="min-h-screen bg-neutral-50 antialiased dark:bg-linear-to-b dark:from-neutral-950 dark:to-neutral-900 max-w-screen overflow-x-hidden">
    <div class="fixed top-0 w-full max-w-screen z-99">
        <?php if (isset($component)) { $__componentOriginald71f23167cd248936dc2189ec4e6af31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald71f23167cd248936dc2189ec4e6af31 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-top','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-top'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald71f23167cd248936dc2189ec4e6af31)): ?>
<?php $attributes = $__attributesOriginald71f23167cd248936dc2189ec4e6af31; ?>
<?php unset($__attributesOriginald71f23167cd248936dc2189ec4e6af31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald71f23167cd248936dc2189ec4e6af31)): ?>
<?php $component = $__componentOriginald71f23167cd248936dc2189ec4e6af31; ?>
<?php unset($__componentOriginald71f23167cd248936dc2189ec4e6af31); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2)): ?>
<?php $attributes = $__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2; ?>
<?php unset($__attributesOriginal5d959a11ff826b3fd89e60f60adf4cb2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2)): ?>
<?php $component = $__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2; ?>
<?php unset($__componentOriginal5d959a11ff826b3fd89e60f60adf4cb2); ?>
<?php endif; ?>
    </div>

    <main>
        <?php echo e($slot); ?>

    </main>

    <?php if (isset($component)) { $__componentOriginal868091fdcca1b7cd44d9608210d3c88a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal868091fdcca1b7cd44d9608210d3c88a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal868091fdcca1b7cd44d9608210d3c88a)): ?>
<?php $attributes = $__attributesOriginal868091fdcca1b7cd44d9608210d3c88a; ?>
<?php unset($__attributesOriginal868091fdcca1b7cd44d9608210d3c88a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal868091fdcca1b7cd44d9608210d3c88a)): ?>
<?php $component = $__componentOriginal868091fdcca1b7cd44d9608210d3c88a; ?>
<?php unset($__componentOriginal868091fdcca1b7cd44d9608210d3c88a); ?>
<?php endif; ?>

    <?php app('livewire')->forceAssetInjection(); ?>
<?php echo app('flux')->scripts(); ?>

</body>

</html>
<?php /**PATH C:\Users\Acer\Downloads\DigipalReborn\resources\views/components/layouts/app/top.blade.php ENDPATH**/ ?>