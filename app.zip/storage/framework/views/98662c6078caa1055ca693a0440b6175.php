<footer class="bg-stone-950 dark:bg-stone-950 text-stone-300 py-12 sm:py-16">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">

            <!-- Footer Section 1: Company Info -->
            <div class="flex flex-col items-start text-left">
                <a href="#" class="inline-flex items-center space-x-2 mb-4">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="h-10" alt="Digipal Logo">
                </a>
                <p class="text-stone-400 leading-relaxed max-w-sm">
                    Empowering businesses with innovative digital solutions to thrive in the online world.
                </p>
                <div class="flex space-x-4 mt-6">
                    <a href="#" target="_blank" aria-label="Facebook"
                        class="text-stone-400 hover:text-green-500 transition transform hover:scale-110">
                        <?php if (isset($component)) { $__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.facebook','data' => ['class' => 'w-6 h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.facebook'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442)): ?>
<?php $attributes = $__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442; ?>
<?php unset($__attributesOriginal8fbd968951d5a4da67c8b8a12bdd7442); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442)): ?>
<?php $component = $__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442; ?>
<?php unset($__componentOriginal8fbd968951d5a4da67c8b8a12bdd7442); ?>
<?php endif; ?>
                    </a>
                    
                    <a href="#" target="_blank" aria-label="Instagram"
                        class="text-stone-400 hover:text-green-500 transition transform hover:scale-110">
                        <?php if (isset($component)) { $__componentOriginala94603789a3397061ae5e0ddf097082b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala94603789a3397061ae5e0ddf097082b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.instagram','data' => ['class' => 'w-6 h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.instagram'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala94603789a3397061ae5e0ddf097082b)): ?>
<?php $attributes = $__attributesOriginala94603789a3397061ae5e0ddf097082b; ?>
<?php unset($__attributesOriginala94603789a3397061ae5e0ddf097082b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala94603789a3397061ae5e0ddf097082b)): ?>
<?php $component = $__componentOriginala94603789a3397061ae5e0ddf097082b; ?>
<?php unset($__componentOriginala94603789a3397061ae5e0ddf097082b); ?>
<?php endif; ?>
                    </a>
                    <a href="#" target="_blank" aria-label="LinkedIn"
                        class="text-stone-400 hover:text-green-500 transition transform hover:scale-110">
                        <?php if (isset($component)) { $__componentOriginal74ea8ed9b57f968e47449b6924350724 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74ea8ed9b57f968e47449b6924350724 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.linkedin','data' => ['class' => 'w-6 h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.linkedin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74ea8ed9b57f968e47449b6924350724)): ?>
<?php $attributes = $__attributesOriginal74ea8ed9b57f968e47449b6924350724; ?>
<?php unset($__attributesOriginal74ea8ed9b57f968e47449b6924350724); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74ea8ed9b57f968e47449b6924350724)): ?>
<?php $component = $__componentOriginal74ea8ed9b57f968e47449b6924350724; ?>
<?php unset($__componentOriginal74ea8ed9b57f968e47449b6924350724); ?>
<?php endif; ?>
                    </a>
                </div>
            </div>

            <!-- Footer Section 2: Quick Links -->
            <div class="flex flex-col items-start text-left">
                <h4 class="text-xl font-bold text-white mb-4">Company</h4>
                <ul class="space-y-3">
                    <li><a href="#" class="text-stone-400 hover:text-green-400 transition">About Us</a></li>
                    <li><a href="#" class="text-stone-400 hover:text-green-400 transition">Our Team</a></li>
                    <li><a href="#" class="text-stone-400 hover:text-green-400 transition">Careers</a></li>
                    <li><a href="#" class="text-stone-400 hover:text-green-400 transition">Blog</a></li>
                </ul>
            </div>

            <!-- Footer Section 3: Services -->
            <div class="flex flex-col items-start text-left">
                <h4 class="text-xl font-bold text-white mb-4">Services</h4>
                <ul class="space-y-3">
                    <li>
                        <a href="#" class="text-stone-400 hover:text-green-400 transition">
                            360 Digital Marketing
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-stone-400 hover:text-green-400 transition">
                            Video Production
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-stone-400 hover:text-green-400 transition">
                            Social Media Marketing
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-stone-400 hover:text-green-400 transition">
                            Podcast Creation
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-stone-400 hover:text-green-400 transition">
                            Web Development
                        </a>
                    </li>
                    <li>
                        <a href="#" class="text-stone-400 hover:text-green-400 transition">
                            SEO Optimization
                        </a>
                    </li>
                </ul>
            </div>

            <!-- Footer Section 4: Contact & Social -->
            <div class="flex flex-col items-start text-left">
                <h4 class="text-xl font-bold text-white mb-4">Contact Us</h4>
                <ul class="space-y-3">
                    <li class="flex items-center justify-start space-x-2">
                        <?php if (isset($component)) { $__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.envelope','data' => ['class' => 'w-5 h-5 text-green-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.envelope'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-green-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f)): ?>
<?php $attributes = $__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f; ?>
<?php unset($__attributesOriginalb2620669e6f3f9a8ec8b91c4a73fca6f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f)): ?>
<?php $component = $__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f; ?>
<?php unset($__componentOriginalb2620669e6f3f9a8ec8b91c4a73fca6f); ?>
<?php endif; ?>
                        <a href="mailto:hello@digipalsolutions.com.np"
                            class="text-stone-400 hover:text-green-400 transition">hello@digipalsolutions.com.np</a>
                    </li>
                    <li class="flex items-center justify-start space-x-2">
                        <?php if (isset($component)) { $__componentOriginal3b273e6b331c9518de08da49e1886441 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b273e6b331c9518de08da49e1886441 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.phone','data' => ['class' => 'w-5 h-5 text-green-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.phone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-green-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b273e6b331c9518de08da49e1886441)): ?>
<?php $attributes = $__attributesOriginal3b273e6b331c9518de08da49e1886441; ?>
<?php unset($__attributesOriginal3b273e6b331c9518de08da49e1886441); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b273e6b331c9518de08da49e1886441)): ?>
<?php $component = $__componentOriginal3b273e6b331c9518de08da49e1886441; ?>
<?php unset($__componentOriginal3b273e6b331c9518de08da49e1886441); ?>
<?php endif; ?>
                        <a href="tel:+977 01-5912819" class="text-stone-400 hover:text-green-400 transition">
                            +977 01-5912819
                        </a>
                    </li>
                    <li class="flex items-center justify-start space-x-2">
                        <?php if (isset($component)) { $__componentOriginal0d48bd54d72df81b49ee07c1a3735f04 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.map-pin','data' => ['class' => 'w-5 h-5 text-green-400']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.map-pin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-green-400']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04)): ?>
<?php $attributes = $__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04; ?>
<?php unset($__attributesOriginal0d48bd54d72df81b49ee07c1a3735f04); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0d48bd54d72df81b49ee07c1a3735f04)): ?>
<?php $component = $__componentOriginal0d48bd54d72df81b49ee07c1a3735f04; ?>
<?php unset($__componentOriginal0d48bd54d72df81b49ee07c1a3735f04); ?>
<?php endif; ?>
                        <a href="https://maps.app.goo.gl/jvy4yUnWNXja1cpCA" target="_blank"
                            class="text-stone-400 hover:text-green-400 transition">Kathmandu, Nepal</a>
                    </li>
                </ul>
            </div>

        </div>

        <hr class="border-stone-800 my-10">

        <!-- Bottom Bar: Copyright & Links -->
        <div
            class="flex md:flex-row flex-col-reverse items-center justify-center gap-2 md:justify-between text-stone-500 text-sm">
            <p>&copy; <?php echo e(date('Y')); ?> Digipal Solutions. All rights reserved.</p>
            <div class="flex items-center space-x-4">
                <a href="#" class="hover:underline">Privacy Policy</a>
                <a href="#" class="hover:underline">Terms & Conditions</a>
                
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Acer\Downloads\DigipalReborn\resources\views/components/app-footer.blade.php ENDPATH**/ ?>